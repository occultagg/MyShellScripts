#!/usr/bin/bash
while read ip pw
do
echo $ip
sshpass -p ${pw} ssh-copy-id -o StrictHostKeyChecking=no root@${ip}
echo done
done < host.txt
